package org.libx.libappdatabase;

import org.zkoss.zul.Window;

public class MainWindowController extends Window {
    /* currently empty */
}
