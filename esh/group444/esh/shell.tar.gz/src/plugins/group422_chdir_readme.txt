What the plugin does:
	 It is used to change the current working directory to another directory

Created by:
   danh0902 and aemoore

Syntax:
   cd <directory>
   Example: cd, cd ~, cd ~cs3214/bin
