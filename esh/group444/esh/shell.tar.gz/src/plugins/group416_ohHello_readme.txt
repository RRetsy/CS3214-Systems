Group Number
------------
416

Student Information
-------------------
Scott Brink sbrink@vt.edu
Bryce Langlotz brycel@vt.edu

How To Execute Plugin
---------------------

From your command line execute the command:

hello

Description of Functionality
---------------------------

Oh Hello there! 
Need a friend? Enter 'hello' on your command line!
