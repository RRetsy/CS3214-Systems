Group 461

This plugin changes the prompt to display the current working directory

when implemented, the prompt should look like this:

    cwd$

run the test by calling: ~cs3214/bin/stdriver.py -p plugins pluins/<name of your test file> 
