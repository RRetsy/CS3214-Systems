What the plugin does:
	 It is used to convert a degree in Farenheit to Celcius, and vice versa

Created by:
   danh0902 and aemoore

Syntax:
   convertDegrees <degree> <type of degree>
   Example: 
   		convertDegrees 86 F
   		convertDegrees 27 C
