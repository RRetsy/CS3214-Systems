Group Number
------------
416

Student Information
-------------------
Scott Brink sbrink@vt.edu
Bryce Langlotz brycel@vt.edu

How To Execute Plugin
---------------------

From your command line execute the command:

intToBinary <number>

Description of Functionality
---------------------------

Turn any old number into an extraordinary binary number!
From the command line run 'intToBinary 7', just put your favorite number instead of 7!
