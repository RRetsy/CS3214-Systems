about:
This plugin works as a summation tool. If given one integer argument, it will add all numbers from 1 to that number. If two arguments are given, it will add them and return the value

created by:
aemoore and danh0902

Example use:
sum [number1] [number2]
	e.g. sum 4
	>    The Sum from 1 to 4 is 10
		sum 5 9
		The sum of 5 and 9 is 14