Group Number
------------
416

Student Information
-------------------
Scott Brink sbrink@vt.edu
Bryce Langlotz brycel@vt.edu

How To Execute Plugin
---------------------

From your command line execute the command:

startTimer

Use Ctrl-C to kill


Description of Functionality
---------------------------

Use 'startTimer' on the command line to start a timer that goes forever and ever! 


literally it will go forever so use ctrl-c to kill it when your bored of watching time go by
