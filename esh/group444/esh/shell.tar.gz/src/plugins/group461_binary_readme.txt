Group 461

This plugin converts a base 10 number into binary

To run this plugin, type binary followed by a base 10 number
ex: esh> binary 72
    0000000001001000

run the test by calling: ~cs3214/bin/stdriver.py -p plugins plugins/<name of test file>
