ESH POKEDEX (pkdx)
Plugin by: Artur Aguiar
=======================

Welcome to the very best (hopefully only) Kanto Pokedex port for the extensible shell!

SETUP:
	Move the .so file to the directory you will use to load plugins from (e.g. <esh dir>/plugins).
	When executing esh, use the -p argument and pass the plugin directory where you put the pkdx .so file (e.g. ./esh -p plugins).
	Esh will load with the plugins in the directory including pkdx.


USAGE:
	pkdx [FLAGS] [POKEID]	

	You can view help by using the -h flag (i.e. 'pkdx -h').
	A listing is provided with the -l flag.
	The credits are printed if given the -c flag.
	
	For finding information about any of the Kanto 151 pokemon use:
	pkdx POKEID

	Where POKEID is the National ID of the pokemon you want to find.
	pkdx will give you a graphical representation of the pokemon, its name, type, and short description.


Have fun and catch them all!
