Plugin Name: oddeven
Functionality: This plugin takes a number as an argument and prints whether the
number is odd or even. If the input is not a valid input an error message is 
displayed
To use: 
esh> oddeven 1234
1234 is even
esh> oddeven -5
-5 is odd
esh> oddeven 7.34223
Input argument must enter an integer