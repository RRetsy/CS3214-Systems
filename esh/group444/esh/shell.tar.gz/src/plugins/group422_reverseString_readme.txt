about:
this plugin takes any word and prints out the reverse of the string. 
The argument is one word that you want to reverse.

created by:
aemoore and danh0902

Example use:
reverse [word_to_reverse]
	e.g. reverse hello
	>    olleh