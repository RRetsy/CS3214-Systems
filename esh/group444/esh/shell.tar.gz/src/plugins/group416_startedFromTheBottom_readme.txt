Group Number
------------
416

Student Information
-------------------
Scott Brink sbrink@vt.edu
Bryce Langlotz brycel@vt.edu

How To Execute Plugin
---------------------

From your command line execute the command:

started

Description of Functionality
---------------------------

Did you start from the bottom like Drake?
Show everyone that you made it to the top by entering 'started' on the command line!

