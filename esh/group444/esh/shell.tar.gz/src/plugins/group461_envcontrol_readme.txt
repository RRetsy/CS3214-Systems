Group 461

This plugin allows setting and reading of enviornment variables

To run this plugin, type either
getenv <variable name>
setenv <variable name> <value>

ex:
setenv SHELLVAR TESTVAL
getenv SHELLVAR

run the test by calling ~cs3214/bin/stdriver.py -p plugins plugins/<name of test file>   
   or by using a plugins.tst file as described by the Insturctors on piazza
