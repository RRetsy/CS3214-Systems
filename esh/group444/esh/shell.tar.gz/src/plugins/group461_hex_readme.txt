Group 461

This plugin converts a base 10 number into hex

To run this plugin, type hex followed by a base 10 number
ex: esh> hex 72
    0000000000000048

run the test by calling: ~cs3214/bin/stdriver.py -p plugins plugins/<name of your test file>
