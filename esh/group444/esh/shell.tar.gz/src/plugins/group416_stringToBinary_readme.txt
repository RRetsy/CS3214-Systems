Group Number
------------
416

Student Information
-------------------
Scott Brink sbrink@vt.edu
Bryce Langlotz brycel@vt.edu

How To Execute Plugin
---------------------

From your command line execute the command:

stringToBinary <string>

Description of Functionality
---------------------------

Turn your words into 1's and 0's that no one can read!
Enter 'stringToBinary word' on the command line, 
swap out 'word' with your favorite word or short story!
