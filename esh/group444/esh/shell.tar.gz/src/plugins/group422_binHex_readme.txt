What it does:
	It converts a decimal number to a binary and a hexadecimal number

Constraint:
	Range of number: [0, 2^31 - 1]

Created by:
   danh0902 and aemoore

Syntax:
   binHex <the decimal number>
   Example: 
   		binHex 100
   		binhex 15
   		binHex 8

