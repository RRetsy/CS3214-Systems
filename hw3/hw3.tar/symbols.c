int C;
int D = 10;
void T(void)
{
}
static int d = 10;
static int b;
static const char * const r = 'r';
extern int U;
static void t(void)
{
	D = U;
}
