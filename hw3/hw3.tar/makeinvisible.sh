#!/bin/bash
gcc -fPIC -shared -o invisible.so readdir.c
