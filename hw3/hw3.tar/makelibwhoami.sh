#!/bin/bash
gcc -fPIC -shared -o libwhoami.so libwhoami.c
